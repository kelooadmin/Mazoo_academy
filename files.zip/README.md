# Mazoo Academy — sayt

5-sinf matematika bo'yicha gamifikatsiyalangan o'quv platformasi. Supabase bazasiga ulangan, static sayt (build kerak emas).

## Fayllar
- `index.html` — sahifa strukturasi
- `style.css` — dizayn
- `app.js` — Supabase bilan ishlash, testlar mantiqi, XP/streak
- `config.js` — Supabase URL va publishable key

## GitHub'ga joylash
1. Repo yarating (yoki mavjudini oching)
2. Shu 4 ta faylni (`index.html`, `style.css`, `app.js`, `config.js`, `README.md`) repo root papkasiga qo'shing
3. Commit va push qiling

## Vercel'ga ulash
1. vercel.com → New Project → GitHub repo'ngizni tanlang
2. Framework: "Other" (static) — build buyrug'i kerak emas
3. Deploy tugmasini bosing

Bir necha soniyada sayt tayyor bo'ladi va link beriladi.

## Keyingi qadamlar
- Qolgan mavzularga testlar qo'shilgach, sayt avtomatik yangi savollarni ko'rsatadi (kod o'zgartirish shart emas — Supabase'dan real vaqtda o'qiydi)
- Mascot, streak bildirishnomalari, ota-ona dashboard — keyingi bosqichda qo'shiladi
